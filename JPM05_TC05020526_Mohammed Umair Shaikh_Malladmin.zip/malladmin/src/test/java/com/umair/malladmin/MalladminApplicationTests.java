package com.umair.malladmin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MalladminApplicationTests {

	@Test
	void contextLoads() {
	}

}
