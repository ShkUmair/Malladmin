package com.umair.malladmin.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.umair.malladmin.entity.Admin;
import com.umair.malladmin.repository.adminrepository;
@Service

public class adminmallservice {
	
	@Autowired
	adminrepository adminrepository;
	public Admin save(Admin adm) {
	return adminrepository.save(adm);
	
	
	}
	
	public Admin getAdmin(int id) {
		return adminrepository.findById(id).get();
		}
		public Admin update(int id,Admin Admin) {
		Admin emps=adminrepository.findById(id).get();
		emps.setName(Admin.getName());
		emps.setPassword(Admin.getPassword()); 
		emps.setMall(Admin.getMall()); 
		emps.setPhone(Admin.getPhone()); 
		return adminrepository.save(emps); 
		}
		public String delete(int id)
		{
		adminrepository.deleteById(id);
		return "Entity deleted" +id;
		}
		public List<Admin> getAdmlist()
		{
		return adminrepository.findAll();
		}
		public adminrepository getmalladminepository() {
		return adminrepository;
		}
		public void setmalladminrepository(adminrepository adminrepository) {
		this.adminrepository = adminrepository;
		}
		}

	
	


