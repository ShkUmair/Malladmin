package com.umair.malladmin.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.umair.malladmin.entity.Admin;
import com.umair.malladmin.service.adminmallservice;
@RestController
@RequestMapping("/malladmin")

public class adminmallcontroller {
	
	@Autowired
	adminmallservice adminmallservice;
	public adminmallservice getadminmallservice() {
	return adminmallservice;
	}
	public void setadminmallservice(adminmallservice adminmallservice) {
	this.adminmallservice = adminmallservice;
	}
	// http://localhost:8071/employees/create - Post
	@PostMapping("/create")
	public Admin addadmin(@RequestBody Admin adm)
	{
	return adminmallservice.save(adm);
	}
	
	@GetMapping(path="/{id}")
	public Admin getAdmin(@PathVariable int id)
	{
	return adminmallservice.getAdmin(id); 
	}
	//http://localhost:8071/employees/id -PUT
	
	
	@PutMapping(path="/{id}") 
	public Admin updateAdmin(@RequestBody Admin Admin,@PathVariable int id)
	{
	return adminmallservice.update(id,Admin); 
	}
	//http://localhost:8071/employees/2 -DELETE
	@DeleteMapping(path="/{id}")
	public String deleteAdmin(@PathVariable int id)
	{
	return adminmallservice.delete(id); 
	}
	//http://localhost:8071/employees GET
	@GetMapping
	public List<Admin> getAllAdmin()
	{
	return adminmallservice.getAdmlist();
	}
	}



	
	

	


