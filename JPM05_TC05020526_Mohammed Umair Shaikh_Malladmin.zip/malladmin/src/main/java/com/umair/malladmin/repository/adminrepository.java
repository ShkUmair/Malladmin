package com.umair.malladmin.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.umair.malladmin.entity.Admin;
@Repository

public interface adminrepository extends JpaRepository<Admin, Integer> {

	
	
	
	
}
