package com.umair.malladmin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MalladminApplication {

	public static void main(String[] args) {
		SpringApplication.run(MalladminApplication.class, args);
	}

}
